<?php
$conn=mysql_connect("localhost","saledu_gih2019","admin@123") or die("Could not connect");
mysql_select_db("saledu_gih2019",$conn) or die("could not connect database");
?>