<A HREF="javascript:window.print()">Click to Print This Page</A>
<body onload="window.print()">
<?php    
    include 'db.php';
    echo "<h1> GIH 2019 </h1>";
    
    //set it to writable location, a place for temp generated PNG files
    $PNG_TEMP_DIR = dirname(__FILE__).DIRECTORY_SEPARATOR.'temp'.DIRECTORY_SEPARATOR;
    
    //html PNG location prefix
    $PNG_WEB_DIR = 'temp/';

    include "qrlib.php";    
    
    //ofcourse we need rights to create temp dir
    if (!file_exists($PNG_TEMP_DIR))
        mkdir($PNG_TEMP_DIR);
    
    
    $filename = $PNG_TEMP_DIR.'test.png';
    
    //processing form input
    //remember to sanitize user input in real-life solution !!!
    $errorCorrectionLevel = 'L';
    if (isset($_REQUEST['level']) && in_array($_REQUEST['level'], array('L','M','Q','H')))
        $errorCorrectionLevel = $_REQUEST['level'];    

    $matrixPointSize = 4;
    if (isset($_REQUEST['size']))
        $matrixPointSize = min(max((int)$_REQUEST['size'], 1), 10);


    if (isset($_REQUEST['data'])) { 
    
        //it's very important!
        if (trim($_REQUEST['data']) == '')
            die('data cannot be empty! <a href="?">back</a>');
            
        // user data
        $filename = $PNG_TEMP_DIR.'test'.md5($_REQUEST['data'].'|'.$errorCorrectionLevel.'|'.$matrixPointSize).'.png';
        QRcode::png($_REQUEST['data'], $filename, $errorCorrectionLevel, $matrixPointSize, 2);    
        
    } else {    
    
        //default data
        echo 'You can provide data in GET parameter: <a href="?data=like_that">like that</a><hr/>';    
        QRcode::png('PHP QR Code :)', $filename, $errorCorrectionLevel, $matrixPointSize, 2);    
        
    }    
        
    //display generated file
    echo '<img src="'.$PNG_WEB_DIR.basename($filename).'" /><hr/>';  
    
    //config form
    echo '<form action="index.php" method="post">
        &nbsp;<input type="hidden" name="data" value="'.(isset($_REQUEST['data'])?htmlspecialchars($_REQUEST['data']):'PHP QR Code :)').'" />&nbsp;
       
       </form>
      
       <hr/>';
      
       
       // Simply:
$date = date('Y-m-d H:i:s');

// Or:
$date = date('Y/m/d H:i:s');

// This would return the date in the following formats respectively:
$date = '2012-03-06 17:33:07';
// Or
$date = '2012/03/06 17:33:07';

/** 
 * This time is based on the default server time zone.
 * If you want the date in a different time zone,
 * say if you come from Nairobi, Kenya like I do, you can set
 * the time zone to Nairobi as shown below.
 */


date_default_timezone_set('Aisa/Kolkata');

// Then call the date functions
$date = date('Y-m-d H:i:s',strtotime('+5 hour 30 minutes'));

//Parking Location Availability

$parkLoc = "SELECT spot FROM `park_space` WHERE is_active = 0 LIMIT 1";
$resultpark = mysql_query( $parkLoc, $conn );
$row = mysql_fetch_assoc($resultpark);
$loc = $row['spot'];
$imgLink = 'map'.$loc.'.png';
       echo "date=$date"."<br/>";
       echo "Vehical No:".$vno=trim($_REQUEST['no']);
       echo "<br/>";
       echo "Ticket Type:".$ttype=trim($_REQUEST['ttype']);
       echo "<br/>";
       echo "Vehical Type:".$vtype= trim($_REQUEST['vtype']);
       echo "<br/>";
       echo "Vehical No:". trim($_REQUEST['no']);  
       echo "<br/>";
       echo "<h1>Location: ".$loc." </h1><br/>";
       echo "<img src='$imgLink'/>";
      
      
      //#####
     
      	 $sql  = "INSERT INTO `park_log` (`p_sr_no`, `v_no`, `maker`, `model`, `body_color`, `v_type`, `location`, `start_time`, `end_time`, `total_time`, `total_pay`, `pay_type`, `flag`) VALUES (NULL, '$vno', '', '$ttype', '', '$vtype', '$loc', '$date', '', '', '', '', '0')";
	       
	          
	           $result = mysql_query( $sql, $conn );
				if(! $result )
				{
				
				
				}
				else
				{
				    
				}

    ?>
</body>
    